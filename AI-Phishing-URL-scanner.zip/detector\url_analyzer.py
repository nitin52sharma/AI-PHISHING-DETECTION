from urllib.parse import urlparse
import ipaddress
import re


def analyze_url(url):
    score = 0
    reasons = []

    # Add HTTPS if no protocol is provided
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    parsed = urlparse(url)
    hostname = parsed.hostname or ""
    lower_url = url.lower()

    # -----------------------------
    # 1. HTTPS CHECK
    # -----------------------------
    if parsed.scheme == "http":
        score += 20
        reasons.append("Website is not using HTTPS")

    # -----------------------------
    # 2. @ SYMBOL CHECK
    # -----------------------------
    if "@" in url:
        score += 20
        reasons.append("URL contains an @ symbol")

    # -----------------------------
    # 3. VERY LONG URL
    # -----------------------------
    if len(url) > 100:
        score += 15
        reasons.append("URL is unusually long")

    # -----------------------------
    # 4. IP ADDRESS CHECK
    # -----------------------------
    if hostname:
        try:
            ipaddress.ip_address(hostname)
            score += 30
            reasons.append("URL uses an IP address instead of a domain")
        except ValueError:
            pass

    # -----------------------------
    # 5. SUSPICIOUS KEYWORDS
    # -----------------------------
    suspicious_words = [
        "verify",
        "verification",
        "password",
        "bank",
        "confirm",
        "login",
        "signin",
        "account",
        "update",
        "secure",
        "payment",
        "wallet"
    ]

    found_words = []

    for word in suspicious_words:
        if word in lower_url:
            found_words.append(word)

    if found_words:
        keyword_score = min(len(found_words) * 5, 20)
        score += keyword_score

        reasons.append(
            "Suspicious keyword(s): " + ", ".join(found_words)
        )

    # -----------------------------
    # 6. TOO MANY SUBDOMAINS
    # -----------------------------
    if hostname:
        parts = hostname.split(".")

        if len(parts) >= 4:
            score += 10
            reasons.append("Domain contains an unusually high number of subdomains")

    # -----------------------------
    # 7. SUSPICIOUS DASHES
    # -----------------------------
    if hostname.count("-") >= 3:
        score += 10
        reasons.append("Domain contains multiple hyphens")

    # -----------------------------
    # 8. URL ENCODED CHARACTERS
    # -----------------------------
    if "%" in url:
        score += 5
        reasons.append("URL contains encoded characters")

    # -----------------------------
    # 9. SUSPICIOUS FILE EXTENSIONS
    # -----------------------------
    suspicious_extensions = [
        ".exe",
        ".scr",
        ".bat",
        ".cmd",
        ".zip"
    ]

    found_extensions = []

    for extension in suspicious_extensions:
        if extension in lower_url:
            found_extensions.append(extension)

    if found_extensions:
        score += 15
        reasons.append(
            "Suspicious file type detected: "
            + ", ".join(found_extensions)
        )

    # -----------------------------
    # 10. MULTIPLE DOTS IN DOMAIN
    # -----------------------------
    if hostname.count(".") >= 4:
        score += 5
        reasons.append("Domain structure looks unusual")

    # -----------------------------
    # 11. RANDOM-LOOKING LONG HOSTNAME
    # -----------------------------
    if len(hostname) > 50:
        score += 10
        reasons.append("Hostname is unusually long")

    # -----------------------------
    # 12. NUMBERS IN DOMAIN
    # -----------------------------
    if hostname:
        number_count = sum(char.isdigit() for char in hostname)

        if number_count >= 4:
            score += 5
            reasons.append("Domain contains an unusual number of digits")

    # -----------------------------
    # LIMIT SCORE
    # -----------------------------
    score = min(score, 100)

    # -----------------------------
    # RISK LEVEL
    # -----------------------------
    if score >= 60:
        risk = "HIGH"
    elif score >= 25:
        risk = "MEDIUM"
    else:
        risk = "LOW"

    return {
        "url": url,
        "score": score,
        "risk": risk,
        "suspicious": score >= 25,
        "reasons": reasons
    }