def generate_explanation(score, risk, reasons):

    if risk == "HIGH":
        recommendation = "🚨 Avoid using this website and do not enter passwords or personal information."

    elif risk == "MEDIUM":
        recommendation = "⚠️ Be cautious. Verify the website address before entering any sensitive information."

    else:
        recommendation = "✅ No major warning signs were detected by this basic scanner. Still verify the website before trusting it."

    if not reasons:
        details = "The scanner did not find any of the basic phishing indicators it checks for."

    elif len(reasons) == 1:
        details = "The scanner found one warning sign: " + reasons[0] + "."

    else:
        details = "The scanner found these warning signs: " + "; ".join(reasons) + "."

    return (
        f"Risk level: {risk}. "
        f"Score: {score}/100. "
        f"{details} "
        f"{recommendation}"
    )