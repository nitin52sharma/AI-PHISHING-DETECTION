from flask import Flask, render_template, request, session
from detector.url_analyzer import analyze_url
from detector.ai_explanation import generate_explanation
from datetime import datetime

app = Flask(__name__)

app.secret_key = "local-project-secret"


@app.route("/", methods=["GET", "POST"])
def home():
    result = None

    if request.method == "POST":
        url = request.form.get("url", "")

        if url:
            result = analyze_url(url)

            result["explanation"] = generate_explanation(
                result["score"],
                result["risk"],
                result["reasons"]
            )

            history = session.get("history", [])

            history.insert(0, {
                "url": result["url"],
                "score": result["score"],
                "risk": result["risk"],
                "time": datetime.now().strftime("%d %b %Y, %I:%M %p")
            })

            # Keep last 10 scans
            session["history"] = history[:10]

    history = session.get("history", [])

    return render_template(
        "index.html",
        result=result,
        history=history
    )


if __name__ == "__main__":
    app.run(debug=True)